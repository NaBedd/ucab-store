import { bootstrap } from '../shell.js';
import {
  listProducts,
  subscribeNewsletter,
} from '../state.js';
import {
  escapeHTML,
  formatCategory,
  formatMoney,
  stars,
  toast,
} from '../ui.js';

await bootstrap();
render();
window.addEventListener('catalog:updated', render);

function render() {
  const mount = document.getElementById('view');
  const products = listProducts();
  const featured = [...products].sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 4);

  mount.innerHTML = `
    <section class="hero">
      <div class="hero-inner">
        <h1>Productos seleccionados, entregados a la velocidad de un clic.</h1>
        <p>Descubre lo mejor del catálogo UCAB Store: tecnología, moda y accesorios, con una experiencia 100% online y offline.</p>
        <div class="cta-row">
          <a href="catalog.html" class="btn btn-accent">Explorar catálogo</a>
          <a href="register.html" class="btn btn-ghost" style="color:#fff;border-color:rgba(255,255,255,.4)">Crear cuenta</a>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="section-inner">
        <h2>¿Por qué comprar con nosotros?</h2>
        <p class="lead">Diseñado pensando en una experiencia moderna y confiable.</p>
        <div class="benefits">
          ${[
            ['🚚', 'Envío rápido', 'Recibe tus pedidos sin esperas innecesarias.'],
            ['🔒', 'Pago seguro', 'Tus datos están protegidos en cada transacción.'],
            ['📶', 'Modo offline', 'Compra incluso sin conexión, sincronizamos después.'],
            ['🎯', 'Selección curada', 'Productos mejor calificados por nuestros clientes.'],
          ].map(([i, t, d]) => `
            <div class="benefit">
              <div class="ico">${i}</div>
              <h3>${t}</h3>
              <p class="muted">${d}</p>
            </div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section" style="background:var(--surface-2)">
      <div class="section-inner">
        <div class="spread">
          <div>
            <h2>Productos destacados</h2>
            <p class="lead">Los favoritos de nuestra comunidad esta semana.</p>
          </div>
          <a href="catalog.html" class="btn btn-ghost">Ver todo</a>
        </div>
        <div class="product-grid">
          ${featured.length === 0
            ? '<p class="empty">El catálogo se está cargando. Vuelve en un instante.</p>'
            : featured.map(card).join('')}
        </div>
      </div>
    </section>

    <section class="newsletter">
      <h2>Únete al newsletter</h2>
      <p>Recibe ofertas y novedades directamente en tu correo.</p>
      <form id="newsletterForm" novalidate>
        <input type="email" required placeholder="tu@correo.com" aria-label="Correo" />
        <button class="btn btn-accent" type="submit">Suscribirme</button>
      </form>
    </section>
  `;

  mount.querySelector('#newsletterForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = e.target.querySelector('input');
    if (!input.value || !input.checkValidity()) { toast('Ingresa un correo válido.'); return; }
    subscribeNewsletter(input.value);
    input.value = '';
    toast('¡Gracias por suscribirte!');
  });
}

function card(p) {
  return `
    <a class="product-card" href="product.html?id=${encodeURIComponent(p.id)}">
      <div class="thumb"><img src="${escapeHTML(p.image)}" alt="${escapeHTML(p.title)}" loading="lazy"/></div>
      <div class="body">
        <div class="title">${escapeHTML(p.title)}</div>
        <div class="meta">${stars(p.rating || 0)} <span class="tag">${escapeHTML(formatCategory(p.category))}</span></div>
        <div class="price">${formatMoney(p.price)}</div>
      </div>
    </a>
  `;
}
